<?php

namespace Controllers;

use Models\User;
use Helpers\ResponseHelper;
use Database\Database;

class UserController {

    private $pdo;
    public function __construct() {
        $this->pdo = (new Database())->connect();
    }

    public function getAll($role) {
        
        User::getAll($this->pdo, $role);
    }

    public function getById($id, $role) {
        
        User::getById($this->pdo, $id, $role);
    }

    public function getUserTeam($id) {
        
        User::getUserTeam($this->pdo, $id);
    }

    public function updateUser($id) {

        $data = json_decode(file_get_contents('php://input'), true);

        if (isset($data['name'], $data['phone'], $data['username'])) {
            User::update($this->pdo, $id, $data['name'], $data['phone'], $data['username'], $data['role']);
        } else {
            ResponseHelper::sendErrorResponse(400, false, 'Invalid input', 'INVALID_INPUT');
        }
    }

    public function updatePassword($id) {

        $data = json_decode(file_get_contents('php://input'), true);

        if (isset($data['newPassword'])) {
            User::updatePassword($this->pdo, $id, $data['newPassword']);
        } else {
            ResponseHelper::sendErrorResponse(400, false, 'Invalid input', 'INVALID_INPUT');
        }
    }

    public function deleteUser($id) {
    
        User::delete($this->pdo, $id);

    }
}
